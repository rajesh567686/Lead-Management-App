import React from 'react';

export class OfficeTel extends React.Component {
    
    render() {
        return (
            <React.Fragment>
                    {this.props.officeTel}
            </React.Fragment>
        )
    }
}